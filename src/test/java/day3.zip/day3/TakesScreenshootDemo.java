package day3;

public class TakesScreenshootDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
