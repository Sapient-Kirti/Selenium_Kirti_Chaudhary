package day3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.*;

import org.testng.annotations.Test;

public class AssertionDemo {
	@Test
	 public void vefifyURL()
	 {
		WebDriver driver=new ChromeDriver();
		driver.get("");
	 }
	@Test
	public void logOut() {
		
		Assert.assertEquals(12, 12);

	}
	
	
	}

